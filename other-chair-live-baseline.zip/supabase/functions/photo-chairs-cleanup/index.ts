import { createClient } from "npm:@supabase/supabase-js@2.116.0";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"};
const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});

Deno.serve(async(req)=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
  try{
    const supabaseUrl=Deno.env.get("SUPABASE_URL"),serviceRoleKey=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if(!supabaseUrl||!serviceRoleKey)throw new Error("Supabase server credentials are missing.");
    const admin=createClient(supabaseUrl,serviceRoleKey,{auth:{persistSession:false,autoRefreshToken:false}});
    const {data:expired,error:listError}=await admin.from("photo_chairs_photos").select("id, storage_path").lte("expires_at",new Date().toISOString()).limit(500);
    if(listError)throw listError;if(!expired?.length)return json({deleted:0});
    const paths=expired.map(row=>row.storage_path).filter(Boolean);
    if(paths.length){const {error:storageError}=await admin.storage.from("photo-chairs").remove(paths);if(storageError)throw storageError}
    const ids=expired.map(row=>row.id);const {error:deleteError}=await admin.from("photo_chairs_photos").delete().in("id",ids);if(deleteError)throw deleteError;
    return json({deleted:ids.length});
  }catch(error){console.error(error);return json({error:error instanceof Error?error.message:String(error)},500)}
});
