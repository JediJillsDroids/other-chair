# Approved assets only

Only current approved portrait artwork belongs here. September visual decisions override exploratory August designs.
